// /*
//  Copyright (c) 2014-present PlatformIO <contact@platformio.org>

//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at

//     http://www.apache.org/licenses/LICENSE-2.0

//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// **/

// #include <calculator.h>
// #include <unity.h>

// void setUp(void) {
//     // set stuff up here
// }

// void tearDown(void) {
//     // clean stuff up here
// }

// void test_calculator_addition(void) {
//     TEST_ASSERT_EQUAL(32, calc.add(25, 7));
// }

// void test_calculator_subtraction(void) {
//     TEST_ASSERT_EQUAL(20, calc.sub(23, 3));
// }

// void test_calculator_multiplication(void) {
//     TEST_ASSERT_EQUAL(50, calc.mul(25, 2));
// }

// void test_calculator_division(void) {
//     TEST_ASSERT_EQUAL(32, calc.div(96, 3));
// }

// void test_expensive_operation(void) {
//     TEST_IGNORE();
// }

// void RUN_UNITY_TESTS() {
//     UNITY_BEGIN();
//     RUN_TEST(test_calculator_addition);
//     RUN_TEST(test_calculator_subtraction);
//     RUN_TEST(test_calculator_multiplication);
//     RUN_TEST(test_calculator_division);
//     RUN_TEST(test_expensive_operation);
//     UNITY_END();
// }

// #ifdef ARDUINO

// #include <Arduino.h>
// void setup() {
//     // NOTE!!! Wait for >2 secs
//     // if board doesn't support software reset via Serial.DTR/RTS
//     delay(2000);

//     RUN_UNITY_TESTS();
// }

// void loop() {
//     digitalWrite(13, HIGH);
//     delay(100);
//     digitalWrite(13, LOW);
//     delay(500);
// }

// #else

// int main(int argc, char **argv) {
//     RUN_UNITY_TESTS();
//     return 0;
// }

// #endif


#include "unity.h"
#include "main.cpp"
extern "C" {
  #include "Chart.h"
}

void reset_inputs() {
  rtU.start = false;
  rtU.stop = false;
  rtU.t_on = false;
  rtU.t_off = false;
  rtU.inc = false;
  rtU.dec = false;
}

void check_outputs(bool expectedOut1, bool expectedOut2, bool expectedOut3, bool expectedOut4, bool expectedOut5) {
  TEST_ASSERT_EQUAL(expectedOut1, rtY.shut);
  TEST_ASSERT_EQUAL(expectedOut2, rtY.a);
  TEST_ASSERT_EQUAL(expectedOut3, rtY.b);
  TEST_ASSERT_EQUAL(expectedOut4, rtY.on);
  TEST_ASSERT_EQUAL(expectedOut4, rtY.off);
}

void test_start() {
//   reset_inputs();
  rtU.start = 1;
  Chart_step();

//   check_outputs(false, true, false, false, true);0
  TEST_ASSERT_EQUAL(1, rtY.shut);
}

// void test_t_on() {
//   reset_inputs();
//   rtU.start = true;
//   Chart_step();

//   rtU.t_on = true;
//   Chart_step();

//   check_outputs(false, true, false, true, false);
// }

// void test_inc() {
//   reset_inputs();
//   rtU.start = true; 
//   Chart_step();

//   rtU.t_on = true; 
//   Chart_step();

//   rtU.inc = true;
//   Chart_step();

//   check_outputs(false, false, true, true, false);
// }

// void test_dec() {
//   reset_inputs();
//   rtU.start = true; 
//   Chart_step();

//   rtU.t_on = true; 
//   Chart_step();

//   rtU.inc = true;
//   Chart_step();

//   rtU.inc = false;
//   Chart_step();

//   rtU.dec = true;
//   Chart_step();

//   check_outputs(false, true, false, true, false);
// }

// void test_stop() {
//   reset_inputs();
//   rtU.start = true; 
//   Chart_step();

//   rtU.t_on = true; 
//   Chart_step();

//   rtU.inc = true;
//   Chart_step();

//   rtU.inc = false;
//   Chart_step();

//   rtU.dec = true;
//   Chart_step();

//   rtU.dec = false;
//   Chart_step();

//   rtU.stop = true;
//   Chart_step();

//   check_outputs(true, false, false, true, false);
// }

// void setUp(void) {
//   // Setup code for each test, if necessary
// }

// void tearDown(void) {
//   // Cleanup code for each test, if necessary
// }

void runTests() {
  RUN_TEST(test_start);
//   RUN_TEST(test_t_on);
//   RUN_TEST(test_inc);
//   RUN_TEST(test_dec);
//   RUN_TEST(test_stop);
}

int main() {
  UNITY_BEGIN();
  runTests();
  UNITY_END();

  return 0;
}
